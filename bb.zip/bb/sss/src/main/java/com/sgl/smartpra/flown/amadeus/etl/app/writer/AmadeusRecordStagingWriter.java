package com.sgl.smartpra.flown.amadeus.etl.app.writer;

import java.util.List;

import org.springframework.batch.item.ItemWriter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.sgl.smartpra.flow.amadeus.etl.app.domain.AmadeusEtlRecord;
import com.sgl.smartpra.flow.amadeus.etl.app.domain.AmadeusRecordStaging;
import com.sgl.smartpra.flown.amadeus.etl.app.repository.AmadeusRecordStagingRepository;

@Component
public class AmadeusRecordStagingWriter<T extends AmadeusEtlRecord> implements ItemWriter<AmadeusRecordStaging> {

	@Autowired
	private AmadeusRecordStagingRepository amadeusRecordStagingRepository;

	@Override
	public void write(List<? extends AmadeusRecordStaging> amadeusRecordStaging) throws Exception {

		amadeusRecordStagingRepository.saveAll(amadeusRecordStaging);
	}

}
