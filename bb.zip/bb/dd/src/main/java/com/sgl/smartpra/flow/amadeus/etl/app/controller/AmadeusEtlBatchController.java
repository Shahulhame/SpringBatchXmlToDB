package com.sgl.smartpra.flow.amadeus.etl.app.controller;

import org.springframework.batch.core.Job;
import org.springframework.batch.core.JobParameters;
import org.springframework.batch.core.JobParametersBuilder;
import org.springframework.batch.core.launch.JobLauncher;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.sgl.smartpra.batch.global.model.InboundFileLog;
import com.sgl.smartpra.flown.amadeus.etl.app.config.FeignConfiguration.BatchGlobalFeignClient;

@RestController
public class AmadeusEtlBatchController {

	@Autowired
	JobLauncher jobLauncher;

	@Autowired
	Job importAmadeusEtlJob;

	@Autowired
	BatchGlobalFeignClient batchGlobalFeignClient;

	@RequestMapping("/amadeus/etl/invokejob")
	public String handle(@RequestParam("inboundFileName") String inboundFileName) throws Exception {

		InboundFileLog inboundFileLog = new InboundFileLog();
		inboundFileLog.setInboundFileName(inboundFileName);
		inboundFileLog.setFileRecordCount(1);
		inboundFileLog.setFileType("amadeus");

		inboundFileLog = batchGlobalFeignClient.createInboundFileLog(inboundFileLog);

		JobParameters jobParameters = new JobParametersBuilder().addLong("time", System.currentTimeMillis())
				.addString("inboundFileName", inboundFileLog.getInboundFileName().toString())
				.addLong("fileId", inboundFileLog.getInboundFileId().longValue()).toJobParameters();
		jobLauncher.run(importAmadeusEtlJob, jobParameters);

		return "Batch job has been invoked";
	}
}
