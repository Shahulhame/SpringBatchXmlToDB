package com.sgl.smartpra.flown.amadeus.etl.app.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.sgl.smartpra.flow.amadeus.etl.app.domain.AmadeusNewTaxStaging;



@Repository
public interface AmadeusNewTaxStagingRepository  extends JpaRepository<AmadeusNewTaxStaging, Integer>{

}
