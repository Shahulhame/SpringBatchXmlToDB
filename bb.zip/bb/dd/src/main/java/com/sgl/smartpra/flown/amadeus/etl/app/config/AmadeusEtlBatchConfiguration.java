package com.sgl.smartpra.flown.amadeus.etl.app.config;

import java.util.HashMap;
import java.util.Map;

import javax.persistence.EntityManagerFactory;

import org.springframework.batch.core.Job;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing;
import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
import org.springframework.batch.core.configuration.annotation.StepBuilderFactory;
import org.springframework.batch.core.configuration.annotation.StepScope;
import org.springframework.batch.core.launch.support.RunIdIncrementer;
import org.springframework.batch.item.ItemProcessor;
import org.springframework.batch.item.ItemWriter;
import org.springframework.batch.item.file.FlatFileItemReader;
import org.springframework.batch.item.file.LineMapper;
import org.springframework.batch.item.file.mapping.BeanWrapperFieldSetMapper;
import org.springframework.batch.item.file.mapping.FieldSetMapper;
import org.springframework.batch.item.file.mapping.PatternMatchingCompositeLineMapper;
import org.springframework.batch.item.file.transform.LineTokenizer;
import org.springframework.batch.item.support.ClassifierCompositeItemProcessor;
import org.springframework.batch.item.support.ClassifierCompositeItemWriter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.classify.Classifier;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.task.SimpleAsyncTaskExecutor;
import org.springframework.core.task.TaskExecutor;
import org.springframework.transaction.PlatformTransactionManager;

import com.sgl.smartpra.batch.yqyr.app.domain.YQYRConcurrence;
import com.sgl.smartpra.batch.yqyr.app.domain.YQYRMasImposedHdr;
import com.sgl.smartpra.batch.yqyr.app.domain.YQYRMasResltingFareCl;
import com.sgl.smartpra.batch.yqyr.app.domain.YQYRMasTblCxrAppl;
import com.sgl.smartpra.batch.yqyr.app.domain.YQYRMasTblCxrFlight;
import com.sgl.smartpra.batch.yqyr.app.domain.YQYRMasTblGeoZone;
import com.sgl.smartpra.batch.yqyr.app.domain.YQYRMasTblRbdTable;
import com.sgl.smartpra.batch.yqyr.app.domain.YQYRMasTblTxtTable;
import com.sgl.smartpra.batch.yqyr.app.domain.YQYRMasTktDesgr;
import com.sgl.smartpra.batch.yqyr.app.domain.YQYRRecord;
import com.sgl.smartpra.batch.yqyr.app.domain.YQYRServiceFee;
import com.sgl.smartpra.batch.yqyr.app.listener.JobCompletionNotificationListener;
import com.sgl.smartpra.flow.amadeus.etl.app.domain.AmadeusRecordDetailStaging;
import com.sgl.smartpra.flow.amadeus.etl.app.domain.AmadeusRecordStaging;
import com.sgl.smartpra.flow.amadeus.etl.app.domain.FooterDetails;
import com.sgl.smartpra.flow.amadeus.etl.app.domain.HeaderDetails;
import com.sgl.smartpra.flow.amadeus.etl.app.domain.VcrFlightHeaderStaging;
import com.sgl.smartpra.flown.amadeus.etl.app.writer.AmadeusRecordStagingWriter;
import com.sgl.smartpra.flow.amadeus.etl.app.domain.AmadeusEtlRecord;

@Configuration
@EnableBatchProcessing
public class AmadeusEtlBatchConfiguration {

	@Autowired
	public JobBuilderFactory jobBuilderFactory;

	@Autowired
	public StepBuilderFactory stepBuilderFactory;

	@Autowired
	EntityManagerFactory emf;
	
	@Value("${max-threads}")
	private int maxThreads;

	@Autowired
     private PlatformTransactionManager transactionManager;
	 
	 @Bean
	 public TaskExecutor taskExecutor() {
	 	SimpleAsyncTaskExecutor taskExecutor = new SimpleAsyncTaskExecutor();
	 	taskExecutor.setConcurrencyLimit(maxThreads);
	 	return taskExecutor;
	 }

	@Bean
	public Job importYQYRJob(com.sgl.smartpra.flow.amadeus.etl.app.listener.JobCompletionNotificationListener listener, Step importData) {

		 return jobBuilderFactory
				.get("importAmadeusJob")
				.incrementer(new RunIdIncrementer())
				.listener(listener)
				.flow(importData)
				.end()
				.build();
	}

	@SuppressWarnings("unchecked")
	@Bean
	public Step importData() {
		return stepBuilderFactory.get("AmadeusEtlRecord").<AmadeusEtlRecord, AmadeusEtlRecord>chunk(100)
				.reader(amadeusItemReader(null))
				.processor((ItemProcessor<? super AmadeusEtlRecord, ? extends AmadeusEtlRecord>) amadeusProcessor(amadeusEtlHeaderProcessor()
						
						))
				.writer((ItemWriter<? super AmadeusEtlRecord>)amadeusWriter(amadeusEtlHeaderWriter()
						
						))
				.transactionManager(transactionManager)
				.taskExecutor(taskExecutor())
				.throttleLimit(maxThreads)
				.build();
	}
	

	private ItemWriter<? super AmadeusEtlRecord> amadeusEtlHeaderWriter() {
		// TODO Auto-generated method stub
		return null;
	}

	@Bean
	@StepScope
	public FlatFileItemReader<AmadeusEtlRecord> amadeusItemReader(@Value("#{jobParameters[inboundFileName]}") String resource) {

		FlatFileItemReader<AmadeusEtlRecord> reader = new FlatFileItemReader<AmadeusEtlRecord>();
		reader.setResource(new ClassPathResource("data/"+resource));
		reader.setLineMapper(amadeusLineMapper());
		return reader;
	}

	@Bean
	public LineMapper<AmadeusEtlRecord> amadeusLineMapper() {
		PatternMatchingCompositeLineMapper<AmadeusEtlRecord> mapper = new PatternMatchingCompositeLineMapper<>();

		Map<String, LineTokenizer> tokenizers = new HashMap<String, LineTokenizer>(10);
		tokenizers.put("1*", (new HeaderDetails()).lineTokenizer());
		tokenizers.put("2*", (new AmadeusRecordStaging()).lineTokenizer());
		tokenizers.put("9*", (new FooterDetails()).lineTokenizer());
		
		mapper.setTokenizers(tokenizers);

		Map<String, FieldSetMapper<AmadeusEtlRecord>> mappers = new HashMap<String, FieldSetMapper<AmadeusEtlRecord>>();
		mappers.put("1*", (new HeaderDetails()).fieldSetMapper());
		mappers.put("2*",(new AmadeusRecordStaging()).fieldSetMapper());
		mappers.put("9*", (new FooterDetails()).fieldSetMapper());
	

		return mapper;
	}

	@Bean
	public ItemWriter<? super AmadeusEtlRecord> amadeusEtlHeaderWriter1() {
		return new AmadeusRecordDetailStaging().writer();
	}

	
	

	@SuppressWarnings("serial")
	@Bean
	public ClassifierCompositeItemWriter<? extends AmadeusEtlRecord> amadeusWriter(
			ItemWriter<? super AmadeusEtlRecord> amadeusEtlheaderWriter
			
			) {
		ClassifierCompositeItemWriter<AmadeusEtlRecord> classifierCompositeItemWriter = new ClassifierCompositeItemWriter<>();
		classifierCompositeItemWriter.setClassifier(new Classifier<AmadeusEtlRecord, ItemWriter<? super AmadeusEtlRecord>>() {
		
			@Override
			public ItemWriter<? super AmadeusEtlRecord> classify(AmadeusEtlRecord classifiable) {
				if (classifiable instanceof AmadeusRecordDetailStaging) {
					return amadeusEtlHeaderWriter();
				
				}

				return null;
			}

		});
		return classifierCompositeItemWriter;
	}
	
	@Bean
	@StepScope
	public ItemProcessor<? extends AmadeusEtlRecord, ? extends AmadeusEtlRecord> amadeusEtlHeaderProcessor(){
		return new AmadeusRecordDetailStaging().processor();
	}

	

	@Bean
	  @StepScope
	public ClassifierCompositeItemProcessor<? extends AmadeusEtlRecord, ? extends AmadeusEtlRecord> amadeusProcessor(
			ItemProcessor<? extends AmadeusEtlRecord, ? extends AmadeusEtlRecord> amadeusEtlheaderProcessor
			
			) {
		ClassifierCompositeItemProcessor<AmadeusEtlRecord, AmadeusEtlRecord> classifierCompositeItemProcessor = new ClassifierCompositeItemProcessor<>();
		classifierCompositeItemProcessor
				.setClassifier(new Classifier<AmadeusEtlRecord, ItemProcessor<?, ? extends AmadeusEtlRecord>>() {
					
					@Override
					public ItemProcessor<?, ? extends AmadeusEtlRecord> classify(AmadeusEtlRecord classifiable) {
						if (classifiable instanceof AmadeusRecordDetailStaging) {
							return amadeusEtlheaderProcessor;
						
						}
						return null;

					}

				});
		return classifierCompositeItemProcessor;

	}
	
	
	
	
	
	
	
	
	
}

