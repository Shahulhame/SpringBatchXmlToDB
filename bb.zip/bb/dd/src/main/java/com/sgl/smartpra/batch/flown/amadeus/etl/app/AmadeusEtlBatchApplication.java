package com.sgl.smartpra.batch.flown.amadeus.etl.app;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.circuitbreaker.EnableCircuitBreaker;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;
import org.springframework.cloud.openfeign.EnableFeignClients;
import org.springframework.scheduling.annotation.EnableScheduling;

import springfox.documentation.swagger2.annotations.EnableSwagger2;

@SpringBootApplication
@EnableScheduling
@EnableDiscoveryClient
@EnableCircuitBreaker
@EnableSwagger2
@EnableFeignClients
public class AmadeusEtlBatchApplication {

	public static void main(String[] args) throws Exception {
		SpringApplication.run(AmadeusEtlBatchApplication.class, args);
	}

}