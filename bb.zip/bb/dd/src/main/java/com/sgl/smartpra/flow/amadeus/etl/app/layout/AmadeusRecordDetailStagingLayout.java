package com.sgl.smartpra.flow.amadeus.etl.app.layout;

import java.util.ArrayList;

import com.sgl.smartpra.batch.global.model.FixedLengthFieldLayout;
import com.sgl.smartpra.batch.global.model.FixedLengthRecordLayout;

public class AmadeusRecordDetailStagingLayout extends FixedLengthRecordLayout{

    public AmadeusRecordDetailStagingLayout(){
    	
    	 fixedLengthFieldLayoutList = new ArrayList<FixedLengthFieldLayout>();
         fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("issAirline",2,4));
         fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("documentNumber",5,14));
         fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("couponNumber",16,16));
         fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("couponNumber",16,16));
         fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("coupons",252,null));
        
         
         
         
       
    }
}
