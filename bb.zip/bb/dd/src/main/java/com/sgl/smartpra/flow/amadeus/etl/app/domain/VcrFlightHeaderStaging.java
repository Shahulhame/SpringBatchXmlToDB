package com.sgl.smartpra.flow.amadeus.etl.app.domain;

import java.io.Serializable;
import javax.persistence.*;

import org.springframework.batch.item.ItemProcessor;
import org.springframework.batch.item.ItemWriter;
import org.springframework.batch.item.file.mapping.FieldSetMapper;
import org.springframework.batch.item.file.transform.LineTokenizer;

import java.sql.Timestamp;


/**
 * The persistent class for the vcr_flight_header_stg database table.
 * 
 */
@Entity
@Table(name="vcr_flight_header_stg")
@NamedQuery(name="VcrFlightHeaderStg.findAll", query="SELECT v FROM VcrFlightHeaderStg v")
public class VcrFlightHeaderStaging extends AmadeusEtlRecord  implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="vcr_flown_hdr_id")
	private int vcrFlownHdrId;

	

	@Column(name="file_id")
	private int fileId;

	@Column(name="flight_number")
	private String flightNumber;

	@Column(name="flight_orgin_date")
	private String flightOrginDate;

	
	@Column(name="record_type")
	private String recordType;

	@Column(name="segment_orgin_city")
	private String segmentOrginCity;

	private String status;

	public VcrFlightHeaderStaging() {
	}

	public int getVcrFlownHdrId() {
		return this.vcrFlownHdrId;
	}

	public void setVcrFlownHdrId(int vcrFlownHdrId) {
		this.vcrFlownHdrId = vcrFlownHdrId;
	}

	

	public int getFileId() {
		return this.fileId;
	}

	public void setFileId(int fileId) {
		this.fileId = fileId;
	}

	public String getFlightNumber() {
		return this.flightNumber;
	}

	public void setFlightNumber(String flightNumber) {
		this.flightNumber = flightNumber;
	}

	public String getFlightOrginDate() {
		return this.flightOrginDate;
	}

	public void setFlightOrginDate(String flightOrginDate) {
		this.flightOrginDate = flightOrginDate;
	}

	

	public String getRecordType() {
		return this.recordType;
	}

	public void setRecordType(String recordType) {
		this.recordType = recordType;
	}

	public String getSegmentOrginCity() {
		return this.segmentOrginCity;
	}

	public void setSegmentOrginCity(String segmentOrginCity) {
		this.segmentOrginCity = segmentOrginCity;
	}

	public String getStatus() {
		return this.status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	@Override
	public LineTokenizer lineTokenizer() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public FieldSetMapper<AmadeusEtlRecord> fieldSetMapper() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public ItemProcessor<? extends AmadeusEtlRecord, ? extends AmadeusEtlRecord> processor() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public ItemWriter<? super AmadeusEtlRecord> writer() {
		// TODO Auto-generated method stub
		return null;
	}

}