package com.sgl.smartpra.flow.amadeus.etl.app.domain;

import org.springframework.batch.item.file.mapping.FieldSetMapper;
import org.springframework.batch.item.file.transform.LineTokenizer;

public class FooterDetails {

	private String recordType;

	private String fileId;
	
	private String hashTotal;

	public String getRecordType() {
		return recordType;
	}

	public void setRecordType(String recordType) {
		this.recordType = recordType;
	}

	public String getFileId() {
		return fileId;
	}

	public void setFileId(String fileId) {
		this.fileId = fileId;
	}
	
	

	public String getHashTotal() {
		return hashTotal;
	}

	public void setHashTotal(String hashTotal) {
		this.hashTotal = hashTotal;
	}

	@Override
	public String toString() {
		return "FooterDetails [recordType=" + recordType + ", fileId=" + fileId + ", hashTotal=" + hashTotal + "]";
	}

	public LineTokenizer lineTokenizer() {
		// TODO Auto-generated method stub
		return null;
	}

	public FieldSetMapper<AmadeusEtlRecord> fieldSetMapper() {
		// TODO Auto-generated method stub
		return null;
	}

	

	

	
}
