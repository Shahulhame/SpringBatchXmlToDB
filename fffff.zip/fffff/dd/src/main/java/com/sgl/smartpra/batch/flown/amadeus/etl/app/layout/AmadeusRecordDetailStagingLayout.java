package com.sgl.smartpra.batch.flown.amadeus.etl.app.layout;

import java.util.ArrayList;
import java.util.List;

import com.sgl.smartpra.batch.global.model.FixedLengthFieldLayout;
import com.sgl.smartpra.batch.global.model.FixedLengthRecordLayout;

public class AmadeusRecordDetailStagingLayout extends FixedLengthRecordLayout {

	@SuppressWarnings("rawtypes")
	public AmadeusRecordDetailStagingLayout() {

		List<FixedLengthFieldLayout> fixedLengthFieldLayoutList = new ArrayList<FixedLengthFieldLayout>();
		fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("issAirline", 2, 4));
		fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("documentNumber", 5, 14));
		fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("couponNumber", 16, 16));
		fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("coupons", 252, null));

	}
}
