package com.sgl.smartpra.batch.flown.amadeus.etl.app.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.sgl.smartpra.batch.flown.amadeus.etl.app.domain.AmadeusOldTaxStaging;



@Repository
public interface AmadeusOldTaxStagingRepository  extends JpaRepository<AmadeusOldTaxStaging, Integer>{

}
