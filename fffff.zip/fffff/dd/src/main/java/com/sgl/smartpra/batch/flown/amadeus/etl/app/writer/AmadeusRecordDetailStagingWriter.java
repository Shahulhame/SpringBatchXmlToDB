package com.sgl.smartpra.batch.flown.amadeus.etl.app.writer;

import java.util.ArrayList;
import java.util.List;

import org.springframework.batch.item.ItemWriter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.sgl.smartpra.batch.flown.amadeus.etl.app.domain.AmadeusEtlRecord;
import com.sgl.smartpra.batch.flown.amadeus.etl.app.domain.AmadeusRecordDetailStaging;
import com.sgl.smartpra.batch.flown.amadeus.etl.app.repository.AmadeusRecordDetailStagingRepository;

@Component
public class AmadeusRecordDetailStagingWriter<T extends AmadeusEtlRecord> implements ItemWriter<AmadeusRecordDetailStaging> {

	@Autowired
	private  AmadeusRecordDetailStagingRepository amadeusHeaderRepository;

	@Override
	public void write(List<? extends AmadeusRecordDetailStaging> amadeusRecordDetailStaging) throws Exception {
		int lstLength;
		//amadeusRecordDetailStaging.forEach(amadeusRecordDetail);
		lstLength = amadeusRecordDetailStaging.size();
		for(int i=0;i<lstLength;i++) {
			ArrayList<AmadeusRecordDetailStaging> couponList = ((AmadeusRecordDetailStaging) amadeusRecordDetailStaging.get(i)).getCouponDetailList();
			amadeusHeaderRepository.saveAll(couponList);
			
		
		}

	}

}
