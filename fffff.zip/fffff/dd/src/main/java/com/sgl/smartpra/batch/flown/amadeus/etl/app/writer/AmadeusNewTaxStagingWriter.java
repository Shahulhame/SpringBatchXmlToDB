package com.sgl.smartpra.batch.flown.amadeus.etl.app.writer;

import java.util.List;

import org.springframework.batch.item.ItemWriter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.sgl.smartpra.batch.flown.amadeus.etl.app.domain.AmadeusEtlRecord;
import com.sgl.smartpra.batch.flown.amadeus.etl.app.domain.AmadeusRecordDetailStaging;
import com.sgl.smartpra.batch.flown.amadeus.etl.app.repository.AmadeusNewTaxStagingRepository;

@Component
public class AmadeusNewTaxStagingWriter<T extends AmadeusEtlRecord> implements ItemWriter<AmadeusRecordDetailStaging> {

	@Autowired
	private AmadeusNewTaxStagingRepository amadeusHeaderRepository;

	@Override
	public void write(List<? extends AmadeusRecordDetailStaging> amadeusEtlheadera) throws Exception {
		
		


	}

}
