package com.sgl.smartpra.batch.flown.amadeus.etl.app.domain;

import org.springframework.stereotype.Component;

@Component
public class SharedEntity {

	private AmadeusRecordStaging amadeusRecordStaging;

	public AmadeusRecordStaging getAmadeusRecordStaging() {
		return amadeusRecordStaging;
	}

	public void setAmadeusRecordStaging(AmadeusRecordStaging amadeusRecordStaging) {
		this.amadeusRecordStaging = amadeusRecordStaging;
	}

	

}
