package com.sgl.smartpra.batch.flown.amadeus.etl.app.writer;

import java.util.ArrayList;
import java.util.List;

import org.springframework.batch.item.ItemWriter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.sgl.smartpra.batch.flown.amadeus.etl.app.domain.AmadeusEtlRecord;
import com.sgl.smartpra.batch.flown.amadeus.etl.app.domain.AmadeusNewTaxStaging;
import com.sgl.smartpra.batch.flown.amadeus.etl.app.domain.AmadeusRecordDetailStaging;
import com.sgl.smartpra.batch.flown.amadeus.etl.app.domain.AmadeusRecordStaging;
import com.sgl.smartpra.batch.flown.amadeus.etl.app.repository.AmadeusRecordStagingRepository;
import com.sgl.smartpra.batch.flown.amadeus.etl.app.domain.SharedEntity;

@Component
public class AmadeusRecordStagingWriter<T extends AmadeusEtlRecord> implements ItemWriter<AmadeusRecordStaging> {

	@Autowired
	private AmadeusRecordStagingRepository amadeusRecordStagingRepository;
	
	@Autowired
	private SharedEntity sharedEntity;

	@Override
	public void write(List<? extends AmadeusRecordStaging> amadeusRecordStagingList) throws Exception {
		AmadeusRecordStaging amadeusRecordStaging;
		ArrayList<AmadeusRecordDetailStaging> amadeusRecordDetailStagingList;
		ArrayList<AmadeusNewTaxStaging> amadeusNewTaxStagingList;
		String couponNumber;
		AmadeusRecordDetailStaging amadeusRecordDetailStaging;
		AmadeusNewTaxStaging amadeusNewTaxStaging;
		for (int j = 0; j < amadeusRecordStagingList.size(); j++) {
			amadeusRecordStaging = (AmadeusRecordStaging) amadeusRecordStagingList.get(j);

			// New Tax Details
			amadeusNewTaxStagingList = new ArrayList<AmadeusNewTaxStaging>();
			String taxDetailStr = amadeusRecordStaging.getNewTax();
			int taxCount = taxDetailStr.length() / 14;
			for (int k = 0; k < taxCount; k++) {

				amadeusNewTaxStaging = new AmadeusNewTaxStaging();
				amadeusNewTaxStaging.setNewTaxCode(taxDetailStr.substring((k * 14), (k * 14) + 2));
				amadeusNewTaxStaging.setNewTaxValue(taxDetailStr.substring((k * 14) + 2, (k * 14) + 14));

				amadeusNewTaxStagingList.add(amadeusNewTaxStaging);

			}

			// Coupon table
			amadeusRecordDetailStagingList = new ArrayList<AmadeusRecordDetailStaging>();
			String couponDetailStr = amadeusRecordStaging.getCoupons();
			int couponCount = couponDetailStr.length() / 67;
			for (int i = 0; i < couponCount; i++) {
				System.out.println("Enter into AmadeusDetail");
				couponNumber = couponDetailStr.substring((i * 67), (i * 67) + 2);
				if (couponNumber != null && couponNumber.length() > 0) {
					amadeusRecordDetailStaging = new AmadeusRecordDetailStaging();
					amadeusRecordDetailStaging.setAirlineCode(amadeusRecordDetailStaging.getAirlineCode());
					// amadeusRecordDetailStaging.setDocumentNumber(this.get);
					amadeusRecordDetailStaging.setCouponNumber(amadeusRecordDetailStaging.getCouponNumber());
					// amadeusRecordDetailStaging.setCoupons(couponDetailStr);
					amadeusRecordDetailStaging.setSaleCouponNumber(couponNumber);
					// System.out.println("Coupon" + amadeusRecordDetailStaging.saleCouponNumber);
					amadeusRecordDetailStaging.setOrigin(couponDetailStr.substring((i * 67) + 2, (i * 67) + 7));
					amadeusRecordDetailStaging.setDestination(couponDetailStr.substring((i * 67) + 7, (i * 67) + 12));
					amadeusRecordDetailStaging.setAirlineCode(couponDetailStr.substring((i * 67) + 12, (i * 67) + 15));
					amadeusRecordDetailStaging
							.setSaleFlightNumber(couponDetailStr.substring((i * 67) + 15, (i * 67) + 20));
					amadeusRecordDetailStaging
							.setSaleLocalFlightDate(couponDetailStr.substring((i * 67) + 20, (i * 67) + 26));
					amadeusRecordDetailStaging
							.setFlightArrivalDate(couponDetailStr.substring((i * 67) + 26, (i * 67) + 32));
					amadeusRecordDetailStaging.setSellingClass(couponDetailStr.substring((i * 67) + 32, (i * 67) + 34));
					amadeusRecordDetailStaging.setFareBasis(couponDetailStr.substring((i * 67) + 34, (i * 67) + 39));
					amadeusRecordDetailStaging
							.setReservationStatus(couponDetailStr.substring((i * 67) + 39, (i * 67) + 41));
					amadeusRecordDetailStaging
							.setFreeBaggageAllowance(couponDetailStr.substring((i * 67) + 41, (i * 67) + 44));
					amadeusRecordDetailStaging
							.setInvoluntaryIndicator(couponDetailStr.substring((i * 67) + 44, (i * 67) + 45));
					amadeusRecordDetailStaging.setStopOverCode(couponDetailStr.substring((i * 67) + 45, (i * 67) + 46));
					amadeusRecordDetailStaging
							.setNotValidBeforeDate(couponDetailStr.substring((i * 67) + 46, (i * 67) + 52));
					amadeusRecordDetailStaging
							.setNotValidAfterDate(couponDetailStr.substring((i * 67) + 52, (i * 67) + 58));

					amadeusRecordDetailStagingList.add(amadeusRecordDetailStaging);
				} else {
					break;
				}
			}
			// Add coupon
			amadeusRecordStaging.setAmadeusRecordDetailStgs(amadeusRecordDetailStagingList);
			// Tax Details
			amadeusRecordStaging.setAmadeusNewTaxStgs(amadeusNewTaxStagingList);
		}
		amadeusRecordStagingRepository.saveAll(amadeusRecordStagingList);
		amadeusRecordStagingRepository.flush();
	}

}
