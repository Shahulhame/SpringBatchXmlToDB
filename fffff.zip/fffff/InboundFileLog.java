package com.sgl.smartpra.batch.global.model;

import java.sql.Timestamp;

public class InboundFileLog {

	private Integer inboundFileId;

	private String inboundFileName;

	private String fileType;

	private Integer fileRecordCount;

	private Timestamp uploadStarttime;

	private Timestamp uploadEndtime;

	private String loadStatus;

	private String errorCode;

	private String errorDesc;

	public Integer getInboundFileId() {
		return inboundFileId;
	}

	public void setInboundFileId(Integer inboundFileId) {
		this.inboundFileId = inboundFileId;
	}

	public String getInboundFileName() {
		return inboundFileName;
	}

	public void setInboundFileName(String inboundFileName) {
		this.inboundFileName = inboundFileName;
	}

	public String getFileType() {
		return fileType;
	}

	public void setFileType(String fileType) {
		this.fileType = fileType;
	}

	public Integer getFileRecordCount() {
		return fileRecordCount;
	}

	public void setFileRecordCount(Integer fileRecordCount) {
		this.fileRecordCount = fileRecordCount;
	}

	public Timestamp getUploadStarttime() {
		return uploadStarttime;
	}

	public void setUploadStarttime(Timestamp uploadStarttime) {
		this.uploadStarttime = uploadStarttime;
	}

	public Timestamp getUploadEndtime() {
		return uploadEndtime;
	}

	public void setUploadEndtime(Timestamp uploadEndtime) {
		this.uploadEndtime = uploadEndtime;
	}

	public String getLoadStatus() {
		return loadStatus;
	}

	public void setLoadStatus(String loadStatus) {
		this.loadStatus = loadStatus;
	}

	public String getErrorCode() {
		return errorCode;
	}

	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}

	public String getErrorDesc() {
		return errorDesc;
	}

	public void setErrorDesc(String errorDesc) {
		this.errorDesc = errorDesc;
	}
}
